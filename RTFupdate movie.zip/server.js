const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;
const USERS_FILE = path.join(__dirname, 'users.json');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Ensure users.json exists
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '[]');

const getUsers = () => JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
const saveUsers = (users) => fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));

// Signup route
app.post('/signup', (req, res) => {
    const { username, password } = req.body;
    const users = getUsers();

    if (users.find(user => user.username === username)) {
        return res.send('User already exists. <a href="/signup.html">Try again</a>');
    }

    users.push({ username, password });
    saveUsers(users);
    res.send('Signup successful! <a href="/login.html">Login</a>');
});

// Login route
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = getUsers();

    const user = users.find(user => user.username === username && user.password === password);
    if (!user) return res.send('Invalid login. <a href="/login.html">Try again</a>');

    res.send(`Welcome ${username}!`);
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));